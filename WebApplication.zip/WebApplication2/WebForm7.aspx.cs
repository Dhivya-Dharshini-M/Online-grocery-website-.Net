﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Retrieve the value from the query string
                string billAmount = Request.QueryString["billAmount"];

                // Display or use the bill amount
                if (!string.IsNullOrEmpty(billAmount))
                {
                    Label1.Text = "Bill Amount: " + billAmount;
                }
                else
                {
                    Label1.Text = "No bill amount received.";
                }
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}