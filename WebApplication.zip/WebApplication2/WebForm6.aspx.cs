﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList1.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 250 * 100 / 1000.0;
            }
            else if (price.Equals("250g"))
            {
                rate += 250 * 250 / 1000.0;
            }
            else if (price.Equals("500g"))
            {
                rate += 250 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate += 250 * 750 / 1000;
            }
            else
            {
                rate += 250 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList2.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 66 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 66 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 66 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 66 * 750 / 1000;
            }
            else
            {
                rate = 66 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList3.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 114 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 114 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 114 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 114 * 750 / 1000;
            }
            else
            {
                rate = 114 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList4.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 108 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 108 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 108 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 108 * 750 / 1000;
            }
            else
            {
                rate = 108 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList5.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 69 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 69 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 69 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 69 * 750 / 1000;
            }
            else
            {
                rate = 69 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList6.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 121 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 121 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 121 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 121 * 750 / 1000;
            }
            else
            {
                rate = 121 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList7.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 90 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 90 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 90 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 90 * 750 / 1000;
            }
            else
            {
                rate = 90 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList8.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 79 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 79 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 79 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 79 * 750 / 1000;
            }
            else
            {
                rate = 79 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList9.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 42 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 42 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 42 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 42 * 750 / 1000;
            }
            else
            {
                rate = 42 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList10.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 117 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 117 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 117 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 117 * 750 / 1000;
            }
            else
            {
                rate = 117 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList11.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 45 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 45 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 45 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 45 * 750 / 1000;
            }
            else
            {
                rate = 45 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button21_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList12.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 185 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 185 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 185 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 185 * 750 / 1000;
            }
            else
            {
                rate = 185 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList13.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 62 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 62 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 62 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 62 * 750 / 1000;
            }
            else
            {
                rate = 62 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList14.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 23 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 23 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 23 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 23 * 750 / 1000;
            }
            else
            {
                rate = 23 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList15.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 76 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 76 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 76 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 76 * 750 / 1000;
            }
            else
            {
                rate = 76 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button16_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList16.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 279 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 279 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 279 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 279 * 750 / 1000;
            }
            else
            {
                rate = 279 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button17_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList17.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 308 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 308 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 308 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 308 * 750 / 1000;
            }
            else
            {
                rate = 308 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button18_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList18.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 220 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 220 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 220 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 220 * 750 / 1000;
            }
            else
            {
                rate = 220 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button19_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList19.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 410 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 410 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 410 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 410 * 750 / 1000;
            }
            else
            {
                rate = 410 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button20_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList20.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 150 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 150 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 150 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 150 * 750 / 1000;
            }
            else
            {
                rate = 150 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }
    }
}