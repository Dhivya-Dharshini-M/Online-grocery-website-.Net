﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
                
            
        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            SqlConnection s = new SqlConnection("Data Source=DHIVYADHARSHINI;Initial Catalog=Test_1;Integrated Security=True");
            string name = TextBox1.Text;
            string pass = TextBox2.Text;
            string q = "insert into admin1 (Username,Password)Values('"+name+"','"+pass+"')";
            string q1 = "select cusid from admin1 where Username='" + name + "' and Password='" + pass + "'";
            s.Open();
            SqlCommand cm = new SqlCommand(q, s);
            SqlCommand cmd = new SqlCommand(q1, s);
            int a = cm.ExecuteNonQuery();
            SqlDataReader sd = cmd.ExecuteReader();
            if(a>0)
            {
                Response.Write("<script>alert('Login Successful');</script>");
                if (sd.Read())
                {
                    int cusid = sd.GetInt32(0);
                    TextBox3.Text = cusid.ToString();
                }
            }
            else
            {
                Response.Write("<script>alert('Username/Password invalid!!');</script>");
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection s = new SqlConnection("Data Source=DHIVYADHARSHINI;Initial Catalog=Test_1;Integrated Security=True");
            string name = TextBox1.Text;
            string pass = TextBox2.Text;
            string q = "select cusid from admin1 where Username='" + name + "' and Password='" + pass + "'";
            s.Open();
            SqlCommand cm = new SqlCommand(q, s);
            SqlDataReader sd = cm.ExecuteReader();
            if (sd.Read())
            {
                /*int cusid = sd.GetInt32(0);
                TextBox3.Text = cusid.ToString();*/
                Response.Redirect("WebForm4.aspx");
            }
            else
            {
                Response.Write("<script>alert('Username/Password invalid!!');</script>");
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm4.aspx");
        }
    }
}