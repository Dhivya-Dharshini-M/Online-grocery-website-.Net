﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            double rate=0.0;
            string price = DropDownList1.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 55 * 100 / 1000.0;
            }
            else if (price.Equals("250g"))
            {
                rate += 55 * 250/1000.0;
            }
            else if(price.Equals("500g"))
            {
                rate += 55 * 500 / 1000;
            }
            else if(price.Equals("750g"))
            {
                rate += 55 * 750 / 1000;
            }
            else
            {
                rate += 55 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList2.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 60 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 60 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 60 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 60 * 750 / 1000;
            }
            else
            {
                rate = 60 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList3.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 60 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 60 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 60 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 60 * 750 / 1000;
            }
            else
            {
                rate = 60 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList4.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 50 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 50 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 50 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 50 * 750 / 1000;
            }
            else
            {
                rate = 50 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button6_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList6.SelectedValue;
            if(price.Equals("100g"))
            {
                rate += 76 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 76 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 76 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 76 * 750 / 1000;
            }
            else
            {
                rate = 76 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button5_Click(object sender, EventArgs e)
        {


            double rate = 0.0;
            string price = DropDownList5.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 56 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 56 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 56 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 56 * 750 / 1000;
            }
            else
            {
                rate = 56 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList7.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 56 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 56 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 56 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 56 * 750 / 1000;
            }
            else
            {
                rate = 56 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button8_Click(object sender, EventArgs e)
        {


            double rate = 0.0;
            string price = DropDownList8.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 79 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 79 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 79 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 79 * 750 / 1000;
            }
            else
            {
                rate = 79 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button9_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList9.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 42 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 42 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 42 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 42 * 750 / 1000;
            }
            else
            {
                rate = 42 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            double rate = 0.0;
            string price = DropDownList10.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 44 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 44 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 44 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 44 * 750 / 1000;
            }
            else
            {
                rate = 44 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();

        }

        protected void Button11_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList11.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 36 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 36 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 36 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 36 * 750 / 1000;
            }
            else
            {
                rate = 36 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button21_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList12.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 53 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 53 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 53 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 53 * 750 / 1000;
            }
            else
            {
                rate = 53 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button13_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList13.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 60 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 60 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 60 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 60 * 750 / 1000;
            }
            else
            {
                rate = 60 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button14_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList14.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 47 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 47 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 47 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 47 * 750 / 1000;
            }
            else
            {
                rate = 47 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button15_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList15.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 39 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 39 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 39 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 39 * 750 / 1000;
            }
            else
            {
                rate = 39 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button16_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList16.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 309 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 309 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 309 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 309 * 750 / 1000;
            }
            else
            {
                rate = 309 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button17_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList17.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 152 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 152 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 152 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 152 * 750 / 1000;
            }
            else
            {
                rate = 152 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button18_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList18.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 114 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 114 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 114 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 114 * 750 / 1000;
            }
            else
            {
                rate = 114 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button19_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList19.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 51 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 51 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 51 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 51 * 750 / 1000;
            }
            else
            {
                rate = 51 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button20_Click(object sender, EventArgs e)
        {

            double rate = 0.0;
            string price = DropDownList20.SelectedValue;
            if (price.Equals("100g"))
            {
                rate += 23 * 100 / 1000;
            }
            else if (price.Equals("250g"))
            {
                rate = 23 * 250 / 1000;
            }
            else if (price.Equals("500g"))
            {
                rate = 23 * 500 / 1000;
            }
            else if (price.Equals("750g"))
            {
                rate = 23 * 750 / 1000;
            }
            else
            {
                rate = 23 * 1000 / 1000;
            }
            TextBox1.Text = (double.Parse(TextBox1.Text) + rate).ToString();
        }

        protected void Button22_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm4.aspx");
        }

        protected void Button23_Click(object sender, EventArgs e)
        {
            {
                // Get the value from TextBox1
                string textBoxValue = TextBox1.Text;

                // Redirect to WebForm7 and pass the value using query string
                Response.Redirect("WebForm7.aspx?billAmount=" + textBoxValue);
            }
        }
    }
}